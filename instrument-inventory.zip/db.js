const Database = require('better-sqlite3');
const path = require('path');
const db = new Database(path.join(__dirname, 'data.sqlite'));

function init() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS instruments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      category TEXT,
      name TEXT,
      brand TEXT,
      model TEXT,
      serial TEXT UNIQUE,
      status TEXT DEFAULT 'available',
      location TEXT DEFAULT 'warehouse',
      lastCalibrationDate TEXT,
      nextCalibrationDate TEXT,
      overview TEXT,
      specs TEXT,
      manualPath TEXT
    );

    CREATE TABLE IF NOT EXISTS bookings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      userId INTEGER,
      instrumentId INTEGER,
      startDate TEXT,
      dueDate TEXT,
      returnedDate TEXT,
      remarks TEXT,
      FOREIGN KEY(userId) REFERENCES users(id),
      FOREIGN KEY(instrumentId) REFERENCES instruments(id)
    );
  `);
}

module.exports = { db, init };
