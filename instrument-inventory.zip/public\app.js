const socket = io();
let instruments = [];
let users = [];
let currentUserId = 1;

async function api(path, opts) {
  const res = await fetch('/api' + path, opts);
  return res.json();
}

function el(tag, cls, txt){const e=document.createElement(tag);if(cls)e.className=cls;if(txt)e.textContent=txt;return e}

async function loadUsers(){
  users = await api('/users');
  const sel = document.getElementById('userSelect');
  sel.innerHTML='';
  users.forEach(u=>{const o=document.createElement('option');o.value=u.id;o.textContent=u.name;sel.appendChild(o)});
  sel.value = currentUserId;
  sel.onchange = e=> currentUserId = Number(e.target.value);
}

function animateInView(){
  const obs = new IntersectionObserver(entries=>{
    entries.forEach(en=>{
      if(en.isIntersecting){
        en.target.classList.add('in-view');
        obs.unobserve(en.target);
      }
    });
  },{threshold:0.12});
  document.querySelectorAll('.animate-on-scroll').forEach(elm=>obs.observe(elm));
}

function animateCount(el, to){
  const start = 0; const duration = 800; const step = Math.max(1, Math.floor(to/30));
  let cur = start; const iv = setInterval(()=>{ cur += step; if(cur>=to){ el.textContent = to; clearInterval(iv); } else el.textContent = cur; }, Math.floor(duration/(to/step||1)));
}

function renderDashboard(){
  const main = document.getElementById('main'); main.innerHTML='';
  const wrap = el('div','grid');

  const totalCard = el('div','card animate-on-scroll');
  totalCard.appendChild(el('h2',null,'Total Instruments'));
  const kpi = el('div','kpi'); kpi.textContent = '0'; totalCard.appendChild(kpi);
  wrap.appendChild(totalCard);

  const booked = el('div','card animate-on-scroll');
  booked.appendChild(el('h2',null,'Booked'));
  const kpi2 = el('div','kpi'); kpi2.textContent='0'; booked.appendChild(kpi2);
  wrap.appendChild(booked);

  const dueCard = el('div','card animate-on-scroll');
  dueCard.appendChild(el('h2',null,'Due within 7 days'));
  const kpi3 = el('div','kpi'); kpi3.textContent='0'; dueCard.appendChild(kpi3);
  wrap.appendChild(dueCard);

  main.appendChild(wrap);

  // details table
  const listCard = el('div','card animate-on-scroll');
  listCard.appendChild(el('h2',null,'Recent Instruments'));
  const table = document.createElement('table'); table.className='table';
  table.innerHTML = '<tr><th>SNo</th><th>Name</th><th>Model</th><th>Serial</th><th>Status</th></tr>';
  instruments.slice(0,12).forEach((it,idx)=>{
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${idx+1}</td><td>${it.name}</td><td>${it.model}</td><td>${it.serial}</td><td>${it.status}</td>`;
    if(it.nextCalibrationDate && (new Date(it.nextCalibrationDate)-new Date()) < 7*24*3600*1000) tr.classList.add('red');
    table.appendChild(tr);
  });
  listCard.appendChild(table);
  main.appendChild(listCard);

  animateInView();
  animateCount(kpi, instruments.length);
  animateCount(kpi2, instruments.filter(i=>i.status==='booked').length);
  animateCount(kpi3, instruments.filter(i=>i.nextCalibrationDate && (new Date(i.nextCalibrationDate)-new Date()) < 7*24*3600*1000).length);
}

function renderInventory(){
  const main = document.getElementById('main'); main.innerHTML='';
  const card = el('div','card animate-on-scroll');
  card.appendChild(el('h2', null, 'Inventory'));
  const table = document.createElement('table'); table.className='table';
  table.innerHTML = '<tr><th>SNo</th><th>Name</th><th>Brand</th><th>Model</th><th>Serial</th><th>Status</th><th>Actions</th></tr>';
  instruments.forEach((it, idx)=>{
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${idx+1}</td><td>${it.name}</td><td>${it.brand}</td><td>${it.model}</td><td>${it.serial}</td><td>${it.status}</td><td></td>`;
    const actions = tr.querySelector('td:last-child');
    const edit = el('button','btn ghost','Edit'); edit.onclick=()=>editInstrument(it);
    const del = el('button','btn ghost','Delete'); del.onclick=async()=>{await fetch('/api/instruments/'+it.id,{method:'DELETE'}); loadAll();}
    actions.appendChild(edit);actions.appendChild(del);
    if(it.nextCalibrationDate && (new Date(it.nextCalibrationDate) - new Date()) < 7*24*3600*1000){ tr.classList.add('red') }
    table.appendChild(tr);
  });
  card.appendChild(table);
  main.appendChild(card);
  animateInView();
}

function editInstrument(it){
  const main = document.getElementById('main'); main.innerHTML='';
  const card = el('div','card animate-on-scroll');
  card.appendChild(el('h2',null,'Edit Instrument'));
  const form = document.createElement('form');
  ['category','name','brand','model','serial','location','overview','specs'].forEach(k=>{
    const p = document.createElement('p');
    p.appendChild(el('label',null,k));
    const inp = document.createElement('input'); inp.name=k; inp.value = it[k]||'';
    inp.style.width='100%'; inp.style.padding='8px'; inp.style.margin='6px 0';
    p.appendChild(inp); form.appendChild(p);
  });
  const save = el('button','btn','Save'); save.type='submit';
  form.appendChild(save);
  form.onsubmit = async e=>{ e.preventDefault(); const fd = Object.fromEntries(new FormData(form).entries()); await fetch('/api/instruments/'+it.id,{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(fd)}); loadAll(); };
  card.appendChild(form); main.appendChild(card);
  animateInView();
}

function renderBooking(){
  const main = document.getElementById('main'); main.innerHTML='';
  const card = el('div','card animate-on-scroll'); card.appendChild(el('h2',null,'Booking / Return'));
  const list = el('div');
  instruments.forEach(it=>{
    const row = el('div'); row.style.display='flex'; row.style.justifyContent='space-between'; row.style.alignItems='center'; row.style.padding='8px 0';
    const left = el('div',null, `${it.name} ${it.model} (${it.serial})`);
    const btn = el('button','btn', it.status==='available' ? 'Book' : 'Return');
    btn.onclick = async ()=>{
      if(it.status==='available'){
        await fetch('/api/book',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({userId: currentUserId, instrumentId: it.id, days:7})});
      } else {
        const remarks = prompt('Return remarks:') || '';
        await fetch('/api/return',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({instrumentId: it.id, remarks})});
      }
      loadAll();
    };
    row.appendChild(left); row.appendChild(btn);
    list.appendChild(row);
  });
  card.appendChild(list); main.appendChild(card);
  animateInView();
}

function renderCalibration(){
  const main = document.getElementById('main'); main.innerHTML='';
  const card = el('div','card animate-on-scroll'); card.appendChild(el('h2',null,'Calibration'));
  instruments.forEach(it=>{
    const row = el('div'); row.style.display='flex'; row.style.justifyContent='space-between'; row.style.alignItems='center'; row.style.padding='8px 0';
    const dueMs = it.nextCalibrationDate ? (new Date(it.nextCalibrationDate)-new Date()) : Infinity;
    const days = Math.round(dueMs / (24*3600*1000));
    const left = el('div',null, `${it.name} ${it.model} (${it.serial}) - next in ${isFinite(days)?days+' days':'n/a'}`);
    const btn = el('button','btn', 'Mark Calibrated'); btn.onclick = async ()=>{await fetch('/api/calibrate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({instrumentId: it.id, byUserId: currentUserId})}); loadAll();};
    row.appendChild(left); row.appendChild(btn);
    if(dueMs < 7*24*3600*1000) row.classList.add('red');
    card.appendChild(row);
  });
  main.appendChild(card);
  animateInView();
}

function renderLearning(){
  const main = document.getElementById('main'); main.innerHTML='';
  const card = el('div','card animate-on-scroll'); card.appendChild(el('h2',null,'Learning'));
  instruments.forEach(it=>{
    const row = el('div');
    row.innerHTML = `<strong>${it.name} ${it.model}</strong><div style="color:var(--muted);margin-top:6px">${it.overview||'<i>No overview</i>'}</div>`;
    card.appendChild(row);
  });
  main.appendChild(card);
  animateInView();
}

function setupNav(){
  document.querySelectorAll('.sidebar button').forEach(b=>b.onclick=e=>{document.querySelectorAll('.sidebar button').forEach(x=>x.classList.remove('active'));b.classList.add('active');const v=b.dataset.view; if(v==='dashboard')renderDashboard(); if(v==='inventory')renderInventory(); if(v==='booking')renderBooking(); if(v==='calibration')renderCalibration(); if(v==='learning')renderLearning();});
  document.getElementById('search').addEventListener('input',(e)=>{
    const q = e.target.value.toLowerCase();
    // simple client-side filter: filter instruments shown on inventory
    if(document.querySelector('.sidebar button.active').dataset.view === 'inventory') renderInventory();
  });
}

async function loadAll(){
  instruments = await api('/instruments');
  renderDashboard();
}

socket.on('instruments', data => { instruments = data; renderDashboard(); });

loadUsers(); setupNav(); loadAll();

