const express = require('express');
const http = require('http');
const path = require('path');
const { Server } = require('socket.io');
const bodyParser = require('body-parser');
const cors = require('cors');
const ExcelJS = require('exceljs');
const { db, init } = require('./db');

init();

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

io.on('connection', socket => {
  console.log('socket connected');
});

function broadcastUpdate() {
  const instruments = db.prepare('SELECT * FROM instruments').all();
  io.emit('instruments', instruments);
}

app.get('/api/instruments', (req, res) => {
  const instruments = db.prepare('SELECT * FROM instruments').all();
  res.json(instruments);
});

app.post('/api/instruments', (req, res) => {
  const { category, name, brand, model, serial, location, overview, specs } = req.body;
  const stmt = db.prepare('INSERT INTO instruments (category,name,brand,model,serial,location,overview,specs) VALUES (?,?,?,?,?,?,?,?)');
  const info = stmt.run(category, name, brand, model, serial, location || 'warehouse', overview || '', specs || '');
  broadcastUpdate();
  res.json({ id: info.lastInsertRowid });
});

app.put('/api/instruments/:id', (req, res) => {
  const id = req.params.id;
  const fields = req.body;
  const keys = Object.keys(fields);
  const sets = keys.map(k => `${k}=?`).join(',');
  const stmt = db.prepare(`UPDATE instruments SET ${sets} WHERE id=?`);
  stmt.run(...keys.map(k => fields[k]), id);
  broadcastUpdate();
  res.json({ ok: true });
});

app.delete('/api/instruments/:id', (req, res) => {
  const id = req.params.id;
  db.prepare('DELETE FROM instruments WHERE id=?').run(id);
  broadcastUpdate();
  res.json({ ok: true });
});

app.get('/api/users', (req, res) => {
  const users = db.prepare('SELECT * FROM users').all();
  res.json(users);
});

app.post('/api/book', (req, res) => {
  const { userId, instrumentId, days=7, remarks } = req.body;
  // check availability
  const inst = db.prepare('SELECT * FROM instruments WHERE id=?').get(instrumentId);
  if (!inst) return res.status(404).json({ error: 'Instrument not found' });
  if (inst.status === 'booked') return res.status(400).json({ error: 'Instrument already booked' });

  const start = new Date();
  const due = new Date(start.getTime() + days*24*3600*1000);
  db.prepare('INSERT INTO bookings (userId,instrumentId,startDate,dueDate,remarks) VALUES (?,?,?,?,?)')
    .run(userId, instrumentId, start.toISOString(), due.toISOString(), remarks || '');

  db.prepare('UPDATE instruments SET status=?, location=? WHERE id=?').run('booked', 'with_user', instrumentId);
  broadcastUpdate();

  // generate booking sheet excel
  (async ()=>{
    const workbook = new ExcelJS.Workbook();
    const sheet = workbook.addWorksheet('Booking');
    sheet.addRow(['SNo','Instrument Name','Model','Serial','Booked By','Start Date','Due Date','Remarks']);
    const user = db.prepare('SELECT * FROM users WHERE id=?').get(userId);
    sheet.addRow([1, inst.name, inst.model, inst.serial, user ? user.name : userId, start.toISOString(), due.toISOString(), remarks || '']);
    const filePath = path.join(__dirname, 'public', `booking-${Date.now()}.xlsx`);
    await workbook.xlsx.writeFile(filePath);
  })();

  res.json({ ok: true });
});

app.post('/api/return', (req, res) => {
  const { instrumentId, remarks } = req.body;
  const booking = db.prepare('SELECT * FROM bookings WHERE instrumentId=? AND returnedDate IS NULL ORDER BY id DESC').get(instrumentId);
  if (!booking) return res.status(404).json({ error: 'Active booking not found' });
  const returnedDate = new Date().toISOString();
  db.prepare('UPDATE bookings SET returnedDate=?, remarks=? WHERE id=?').run(returnedDate, remarks || booking.remarks, booking.id);
  db.prepare('UPDATE instruments SET status=?, location=? WHERE id=?').run('available', 'warehouse', instrumentId);
  broadcastUpdate();
  res.json({ ok: true });
});

app.get('/api/bookings', (req, res) => {
  const rows = db.prepare('SELECT b.*, u.name as userName, i.name as instrumentName, i.model as instrumentModel, i.serial as instrumentSerial FROM bookings b LEFT JOIN users u ON b.userId=u.id LEFT JOIN instruments i ON b.instrumentId=i.id ORDER BY b.startDate DESC').all();
  res.json(rows);
});

app.get('/api/calibrations', (req, res) => {
  const now = new Date().toISOString();
  const rows = db.prepare('SELECT * FROM instruments').all().map(i => {
    const next = i.nextCalibrationDate || null;
    const dueIn = next ? (new Date(next) - new Date()) : null;
    return { ...i, dueInMilliseconds: dueIn };
  });
  res.json(rows);
});

app.post('/api/calibrate', (req, res) => {
  const { instrumentId, byUserId } = req.body;
  const now = new Date();
  const next = new Date(now.getTime() + 365*24*3600*1000);
  db.prepare('UPDATE instruments SET lastCalibrationDate=?, nextCalibrationDate=? WHERE id=?').run(now.toISOString(), next.toISOString(), instrumentId);
  broadcastUpdate();
  res.json({ ok: true });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log('Server running on', PORT));
